Here are a few sentences regarding the FeedHelloWorld integration.
This is the place to explain what the integration does, and provide the users with information that will help them use it easily. 
